#ifdef _M_IX86
#include <windows.h>
#else
#include <iostream>
#endif


#include <string.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#include <list>

#include "tardis.h"
#include "asteroid.h"
#include "dalek.h"
#include "asteroids.h"
#include "explosion.h"

using namespace std;

int w;
int h;
double timer = 0;
bool firstT = true;
Tardis tardis;
list<Asteroid*> asteroids;
list<Asteroid*>::iterator itA;
list<Explosion*> explosions;
list<Explosion*>::iterator itE;

void idle(){
	/*if(firstT){
		printf("FRIST B T TRUE\n");
	}else{
		printf("FIRST B T FALSE\n");
	}*/
	timer += 0.5;
	tardis.update();
	for(itA = asteroids.begin(); itA != asteroids.end(); ++itA){
		(**itA).update();
	}
	list<Asteroid*> newAst;
	for(itA = asteroids.begin(); itA != asteroids.end(); ++itA){
		Asteroid *it = *itA;
		if(tardis.checkTardis((it))){
			//printf("TARDIS CAUGHT\n");
			if((**itA).rad <= 2.0/4.0){
			}else{
				Asteroid *newA = new Asteroid((*it).rad/2);
				Asteroid *newB = new Asteroid((*it).rad/2);
				(*newA).modelInit(rand());
				(*newA).init(rand());
				(*newB).modelInit(rand());
				(*newB).init(rand());
				//printf("%f\n", (*it).rad/2);
				(*newA).pos[0] = (*it).pos[0];
				(*newA).pos[1] = (*it).pos[1];
				(*newB).pos[0] = (*it).pos[0];
				(*newB).pos[1] = (*it).pos[1];
				newAst.push_back(newA);
				newAst.push_back(newB);
			}
			explosions.push_back(new Explosion((*it).pos[0], (*it).pos[1]));
			tardis.init();
			continue;
		}
		if(tardis.checkShots((it))){
			if((*it).rad <= 2.0/4.0){
			}else{
				Asteroid *newA = new Asteroid((*it).rad/2);
				Asteroid *newB = new Asteroid((*it).rad/2);
				(*newA).modelInit(rand());
				(*newA).init(rand());
				(*newB).modelInit(rand());
				(*newB).init(rand());
				//printf("%f\n", (*it).rad/2);
				(*newA).pos[0] = (*it).pos[0];
				(*newA).pos[1] = (*it).pos[1];
				(*newB).pos[0] = (*it).pos[0];
				(*newB).pos[1] = (*it).pos[1];
				newAst.push_back(newA);
				newAst.push_back(newB);
			}
			explosions.push_back(new Explosion((*it).pos[0], (*it).pos[1]));
			continue;
		}
		newAst.push_back(it);
	}
	asteroids.clear();
	asteroids = newAst;
	if(asteroids.empty()){
		firstT = true;
	}
	
	list<Explosion*> newEx;
	for(itE = explosions.begin(); itE != explosions.end(); itE++){
		Explosion *it = *itE;
		if((*it).update()){
			newEx.push_back(it);
		}
	}
	explosions.clear();
	explosions = newEx;
	//printf("%f %f\n", tardis.pos[0], tardis.pos[1]);
	glutPostRedisplay();
	/*if(firstT){
		printf("FRIST T E TRUE\n");
	}else{
		printf("FIRST T E FALSE\n");
	}*/
}

void specialKeys(int key, int x, int y){
	float th = 0;
	switch(key){
		case GLUT_KEY_LEFT:
			tardis.left();
			//printf("LEFT\n");
			break;
		case GLUT_KEY_RIGHT:
			tardis.right();
			//printf("RIGHT\n");
			break;
		default:
			break;
	}
}

void keys(unsigned char key, int x, int y){
	switch(key){
		case 'x':	
			tardis.accelerate();
			//printf("ACC\n");
			break;
		case 'z':
			tardis.shoot();
			//printf("SHOOT\n");
			break;
		default:
			break;
	}
}

void drawScene(){
	glMatrixMode( GL_MODELVIEW );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	
	glPushMatrix();
	glLoadIdentity();
	
	if(firstT){
		tardis.modelInit(1);
		tardis.init();
		firstT = false;
		for(int i = 0; i < 4; i++){
			asteroids.push_back(new Asteroid(2));
		}
		int i = 0;
		for(itA = asteroids.begin(); itA != asteroids.end(); itA++){
			(**itA).modelInit(i+10);
			(**itA).init(i+5);
			i++;
		}

	}
	
	float  amb[] = { 0, 0, 0, 1 };	// Ambient material property
	float  lt_amb[] = { .2, .2, .2, 1 };	// Ambient light property
  	float  lt_dif[] = { .8, .8, .8, 1 };	// Ambient light property
  	float  lt_pos[] = {0, .39392, .91914, 0};
  	float  lt_spc[] = { 0, 0, 0, 1 };	// Specular light property
  	
  	glEnable( GL_LIGHT0 );
  	glEnable( GL_LIGHTING );
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, amb );

  	glLightfv( GL_LIGHT0, GL_POSITION, lt_pos );
  	glLightfv( GL_LIGHT0, GL_AMBIENT, lt_amb );
  	glLightfv( GL_LIGHT0, GL_DIFFUSE, lt_dif );
  	glLightfv( GL_LIGHT0, GL_SPECULAR, lt_spc );
	
	glPopMatrix();
	
	tardis.draw();
	for(itA = asteroids.begin(); itA != asteroids.end(); itA++){
		(**itA).draw();
		
	}
	for(itE = explosions.begin(); itE != explosions.end(); itE++){
		(**itE).draw();
	}
	
	glFlush();				// Flush OpenGL queue
    glutSwapBuffers();
    //glutTimerFunc(35, drawScene, 0);
}
